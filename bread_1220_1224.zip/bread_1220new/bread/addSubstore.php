<?php
require("dbconnect.php");
global $conn;
$sql ="insert into substore (p1Num, p2Num, p3num, p1lim, p2lim, p3lim) values (0,0,0,70,70,70)"; //insert 一筆新的
if ($result = mysqli_query($conn,$sql)){
	return "success";
} //SQL真正執行

//addSubstore(); //呼叫函數執行
?>










