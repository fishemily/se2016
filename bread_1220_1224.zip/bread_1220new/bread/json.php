<?php 
require "dbconnect.php";
$i=(int)$_POST["id"];
$newD = date("Y-m-d H:i:s",strtotime("+421 minutes"));
$sql="update game set expire ='$newD' ";
$res=mysqli_query($db,$sql) or die("db error");
echo $newD; //newD; 老師要我們把新的時間echo回去
?>
