<?php
session_start();
require("dbconnect.php");
require("function.php");
if (! isset($_SESSION["uID"]))
	$_SESSION["uID"] = "";
//echo $_SESSION["uID"];
if ( $_SESSION["uID"] < " ") {
	//header("Location: login.php");
	echo "Please Login. <a href='loginForm.php'>Login</a>";
	exit(0);
}

$num=checkNum(); //總店所有欄位資料
$cash=checkCash(); //宣告一變數存字串
$pen=counter();

$totalSub = countSub(); //分店總數


$i=0;  //counter for bombs
$sql="select * from substore";//DB內所有Bomb資料   select all bomb information from DB
$res=mysqli_query($conn,$sql) or die("db error");
$arr = array();  //define an array for bombs

while($row=mysqli_fetch_assoc($res)) {  
	//抓資料，把資料一筆筆存入陣列裡面
	$arr[] = $row; 
	// 每一個Bomb配一個  計數$i ，衍生出 bomb$i、timer$i
	$i++;  // $i為計數，在 id編號 和 傳入都用（這看法是結果論）
}
?>
<script>
<?php
	//print the bomb array to the web page as a javascript object
	echo "var myArray=" . json_encode($arr);
?>
</script>


<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="jquery.js"></script>
<script language="javascript">
	function clic(){
        $.ajax({
        url: 'addSubstore.php',
        data: {}, //我要丟出去的data
        type:"POST",
        dataType:'text',
        success: function(txt){
            alert(txt);
			$('#ex').append('<input type="button" value="分店'+ (i+3) +'">'); //變數控制？
        },

        error: function(xhr, ajaxOptions, thrownError){ 
            alert(xhr.status); 
            alert(thrownError); 
        }
        });

	}
  
    $( document ).ready(function() {
        for (i=0; i<<?php echo $pen ?>; i++){
            $('#ex').append('<input type="button" value="分店'+ (i+3) +'">');
        }
    });
	
function sell() { //用傳入編號i的方式嗎？，         //特定分店賣出的想法來想的話？
	//alert('exploded');
	//use jQuery ajax to call sell.php 賣東西(資料庫處理) ，  回傳"現在金額"
	//每幾秒  for一次分店
	for (i=0; i < myArray.length;i++) {
		$.ajax({
			url: "sell.php",
			dataType: 'html',
			type: 'POST',
			data: { sid : myArray[i]['sID']}, //分店編號要傳進去sell.php裡面
			error: function(response) { //the call back function when ajax call fails
				alert('Ajax request failed!');
				},
			success: function(cashNumber) { 
				// the call back function when ajax call succeed
				// Ajax 應用可以僅向伺服器傳送並取回指定資料
				//如何更動金額
				
				<?php $cash=checkCash(); ?>
				$("#cash").html("總財產：<?php echo $cash['Cash']?>元");
				//$('#cash').show()
				history.go(0);
				}
		});
	}
	
}
	
window.onload = function() { //3秒跑一次sell()
	//check the bomb status every 1 second
    setInterval(function () {
		sell()
    }, 3000);
};
	
</script>
</head>
<table width="800" border="1">
<tr>
<td><form action='sub1.php' method='post'>
 <input type='hidden' name='substore1' value='1'>
 <input type='submit' value='分店一'></form></td>
 <td><form action='sub1.php' method='post'>
 <input type='hidden' name='substore1' value='2'>
 <input type='submit' value='分店二'></form></td>
 
<td><input type="button" value="新增分店" onclick="clic()"></td>
<td rowspan = 3> 總店庫存商品</td>
<td>甲：<?php echo $num['p1Num']?>單位</td><td><input type="button" value="訂購甲商品" onclick="location.href='order.php?id=1'"></td><td>到貨剩餘時間：秒</td>
</tr>
<tr><td colspan="3"></td>

<td>乙：<?php echo $num['p2Num']?>單位</td><td><input type="button" value="訂購乙商品" onclick="location.href='要前往的網頁連結'"></td><td>到貨剩餘時間：秒</td>
</tr>
<tr>
<td colspan="3"><div id="cash">總財產：<?php echo $cash['Cash']?>元</div></td>

<td>丙：<?php echo $num['p3Num']?>單位</td><td><input type="button" value="訂購丙商品" onclick="location.href='要前往的網頁連結'"></td><td>到貨剩餘時間：秒</td>
</tr>
</table>
<!--<?php echo $pen?>-->
<div id="ex"></div> <!-- ex: id:#  class:. -->
</html>