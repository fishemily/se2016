<?php
session_start();
require("dbconnect.php");
require("function.php");
require("addSubstore.php");
if (! isset($_SESSION["uID"]))
	$_SESSION["uID"] = "";
//echo $_SESSION["uID"];
if ( $_SESSION["uID"] < " ") {
	//header("Location: login.php");
	echo "Please Login. <a href='loginForm.php'>Login</a>";
	exit(0);
}
$num = checkNum(); //宣告一變數存字串
$cash = checkCash(); //宣告一變數存字串
$pen = counter();
?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script
  src="https://code.jquery.com/jquery-1.12.4.min.js"
  integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
  crossorigin="anonymous"></script>
  <script>
function clic(){
        $.ajax({
        url: 'addSubstore.php',
        data: {},
        type:"POST",
        dataType:'text',
        success: function(number){
            alert(number);
			history.go(0);
        }, 

        error: function(xhr, ajaxOptions, thrownError){ 
            alert(xhr.status); 
            alert(thrownError); 
        }
        });
    $('#ex').append('<input type="button" value="分店">'); //新功能的話，append的部分會變得不需要
  }
  
  
    $( document ).ready(function() {
        for (i=0; i<<?php echo $pen ?>; i++){
            $('#ex').append('<input type="button" value="分店'+ (i+3) +'">');
        }
    });
	
function checksubproduct() {  //用於"判斷是否已爆炸、處理後果"   
	now= new Date(); //get the current time
	//check each bomb with a for loop
	// myArrayB 是 substore
	for (i=0; i < myArrayB.length;i++) { //i=0 分店一， 分店數量	//印出全部分店和其狀態內容
		// convert the date string into date object in javascript
		// tday=new Date(myArrayB[i]['aTime']); 
		if (myArrayB[i]['p1Num'] >= 0) {
			// 隨機數量 * 單價 ， 直接php抓隨機數量吧
			// myArrayB[i]['p1Num'] * myArrayA[i]['price']
			<?php
				/*  本來就還沒完成
				$rowB['p1Num']
				$price1 = rand(0,$rowB['p1Num']);
				$tmp = $i+1;
				echo "<p>分店."$tmp"</p>";
				//$rowA是select * from product
				$rowA['pName']
				echo product a product b 
				echo product num 
				echo <input type="button" value="訂購商品" onclick="location.href='buy.php?id=".$i."'">
				*/
			?>
	}
			$("#order" + i).attr('src',"images/doughnut.jpg");
<?PHP  
// UPDATE product
// select product
// row = 
?>
			$("#timer"+i).html("<?PHP ECHO row['product']?>")

			//echo "<img src='images/waiting.jpg' id='order$i'><div id='timer$i'>0</div><br />";//echo javascript函數

		} else {
			//set the bomb image  and calculate count down
			//沒爆炸  給圖  給剩餘時間
			$("#order" + i).attr('src',"images/waiting.jpg");
			$("#timer"+i).html(Math.floor((tday-now)/1000))			
		}
	}
}

//javascript, to set the timer on windows load event
// onload 會在網頁載入完成後立即執行，告訴特定的 function 開始工作
window.onload = function () {
    setInterval(function () {
		checksubproduct()
    }, 30000); // 30秒check一次  分店做賣出的動作
};
</script>
<?php
			$i=0;  //counter for bombs
			//select all bomb information from DB
			$sqlB = "select * from substore";
			$resB = mysqli_query($conn,$sqlB) or die("db error");
			$arrB = array();  //define an array for bombs

			while($rowB=mysqli_fetch_assoc($resB)) { 
				$arrB[] = $rowB; 
				echo "<img src='images/waiting.jpg' id='order$i'><div id='timer$i'>0</div><br />";//echo javascript函數
				$i++; //increase counter下一顆炸彈
			}
			//echo "<script>window.location='ingredient.php';</script>";
			$j=0;
			$sqlA = "select * from product"; 
			$resA = mysqli_query($conn,$sqlA);
			$rowA = mysqli_fetch_assoc($resA);
			$arrA = array();
			while($rowA = mysqli_fetch_assoc($resA)) { 
				$arrA[] = $rowA; 
				$j++;
			}
?>
			<script>
			<?php
				echo "var myArrayB=" . json_encode($arrB);
				echo "var myArrayA=" . json_encode($arrA);
			?>
			</script>
</head>
<tr>
<table width="800" border="1">
<td><form action='sub1.php' method='post'>
 <input type='hidden' name='substore1' value='1'>
 <input type='submit' value='分店一'></form></td>

 <td><form action='sub1.php' method='post'>
 <input type='hidden' name='substore1' value='2'>
 <input type='submit' value='分店二'></form></td>
<td><input type="button" value="新增分店" onclick="clic()"></td>
<td rowspan = 3> 總店庫存商品</td>
<td>甲：<?php echo $num['p1Num']?>單位</td><td><input type="button" value="訂購甲商品" onclick="location.href='order.php?id=1'"></td><td>到貨剩餘時間：秒</td>
</tr>
<tr><td colspan="3"></td>

<td>乙：<?php echo $num['p2Num']?>單位</td><td><input type="button" value="訂購乙商品" onclick="location.href='要前往的網頁連結'"></td><td>到貨剩餘時間：秒</td>
</tr>
<tr>
<td colspan="3">總財產：<?php echo $cash['Cash']?>元</td>

<td>丙：<?php echo $num['p3Num']?>單位</td><td><input type="button" value="訂購丙商品" onclick="location.href='要前往的網頁連結'"></td><td>到貨剩餘時間：秒</td>
</tr>
</table>
<!--<?php echo $pen?>-->
<div id="ex"></div> <!-- id:#  class:. -->
</html>