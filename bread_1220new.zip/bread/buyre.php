<?php
session_start();
require("function.php");
$result=search();
?>
<html><head>
<title>結果</title>
</head><body>
<h1>向總店訂貨結果</h1>
<?
$buy1=$_REQUEST["buy1"];
$buy2=$_REQUEST["buy2"];
$buy3=$_REQUEST["buy3"];
?>

</body></html>
