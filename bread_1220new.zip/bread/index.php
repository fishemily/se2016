<?php
session_start();
require("dbconnect.php");
require("function.php");
if (! isset($_SESSION["uID"]))
	$_SESSION["uID"] = "";
//echo $_SESSION["uID"];
if ( $_SESSION["uID"] < " ") {
	//header("Location: login.php");
	echo "Please Login. <a href='loginForm.php'>Login</a>";
	exit(0);
}

$num=checkNum(); //宣告一變數存字串
$cash=checkCash(); //宣告一變數存字串
$pen=counter();
?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script
  src="https://code.jquery.com/jquery-1.12.4.min.js"
  integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
  crossorigin="anonymous"></script>
  <script>
  function clic(){
        $.ajax({
        url: 'addSubstore.php',
        data: {}, //我要丟出去的data
        type:"POST",
        dataType:'text',
        success: function(txt){
            alert(txt);
			$('#ex').append('<input type="button" value="分店'+ (i+3) +'">');
        },

        error: function(xhr, ajaxOptions, thrownError){ 
            alert(xhr.status); 
            alert(thrownError); 
        }
        });

  }
  
  
</script>
<script language="javascript">
    $( document ).ready(function() {
        for (i=0; i<<?php echo $pen ?>; i++){
            $('#ex').append('<input type="button" value="分店'+ (i+3) +'">');
        }
    });
</script>
</head>
<tr>
<table width="800" border="1">
<td><form action='sub1.php' method='post'>
 <input type='hidden' name='substore1' value='1'>
 <input type='submit' value='分店一'></form></td>

 <td><form action='sub1.php' method='post'>
 <input type='hidden' name='substore1' value='2'>
 <input type='submit' value='分店二'></form></td>
<td><input type="button" value="新增分店" onclick="clic()"></td>
<td rowspan = 3> 總店庫存商品</td>
<td>甲：<?php echo $num['p1Num']?>單位</td><td><input type="button" value="訂購甲商品" onclick="location.href='order.php?id=1'"></td><td>到貨剩餘時間：秒</td>
</tr>
<tr><td colspan="3"></td>

<td>乙：<?php echo $num['p2Num']?>單位</td><td><input type="button" value="訂購乙商品" onclick="location.href='要前往的網頁連結'"></td><td>到貨剩餘時間：秒</td>
</tr>
<tr>
<td colspan="3">總財產：<?php echo $cash['Cash']?>元</td>

<td>丙：<?php echo $num['p3Num']?>單位</td><td><input type="button" value="訂購丙商品" onclick="location.href='要前往的網頁連結'"></td><td>到貨剩餘時間：秒</td>
</tr>
</table>
<!--<?php echo $pen?>-->
<div id="ex"></div> <!-- id:#  class:. -->
</html>