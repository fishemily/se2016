<?php
require("dbconnect.php");
function checkNum() {
    global $conn;
    $sql ="select * from mainstore";
    if ($result = mysqli_query($conn,$sql)) { //SQL真正執行
        if ($row=mysqli_fetch_assoc($result)) {
        return $row;
        }
    }
}
?>